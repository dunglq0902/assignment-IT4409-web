/* BÀI B — VIẾT CODE: Giỏ hàng của xưởng in
   Hoàn thiện class GioHang và hàm napGioHang.
   Không đổi tên class, tên phương thức, tên hàm; không sửa phần "DỮ LIỆU ĐÃ CHO". */

// ---------- DỮ LIỆU ĐÃ CHO (không sửa) ----------
const DANH_MUC = [
	{ id: "TC01", ten: "Thiệp cưới cotton", loai: "thiep cuoi", gia: 1500 },
	{ id: "TC02", ten: "Thiệp cưới kraft", loai: "thiep cuoi", gia: 900 },
	{ id: "DT01", ten: "Danh thiếp ép kim", loai: "danh thiep", gia: 1200 },
	{ id: "PB01", ten: "Phong bì lót lụa", loai: "phu kien", gia: 500 }
];

// ---------- PHẦN BẠN VIẾT ----------
class GioHang {
	constructor() {
		// Mỗi dòng của giỏ là một object { id, ten, loai, gia, soLuong }.
		this.dsDong = [];
	}

	// 1. Thêm sản phẩm; trả về true nếu thêm được, false nếu soLuong không hợp lệ.
	them(sanPham, soLuong) {
		if (!Number.isInteger(soLuong) || soLuong <= 0) {
			return false;
		}
		const dong = this.dsDong.find(d => d.id === sanPham.id);
		if (dong) {
			dong.soLuong += soLuong;
		} else {
			const { id, ten, loai, gia } = sanPham;
			this.dsDong.push({ id, ten, loai, gia, soLuong });
		}
		return true;
	}

	// 2. Xoá dòng có id tương ứng; trả về true nếu có xoá, false nếu không tìm thấy.
	xoa(id) {
		const viTri = this.dsDong.findIndex(dong => dong.id === id);
		if (viTri === -1) {
			return false;
		}
		this.dsDong.splice(viTri, 1);
		return true;
	}

	// 3. Tổng tiền cả giỏ.
	tongTien() {
		return this.dsDong.reduce((tong, dong) => tong + dong.gia * dong.soLuong, 0);
	}

	// 4. Object thống kê: { "<loai>": tổng tiền của loại đó, ... }.
	thongKeTheoLoai() {
		const thongKe = new Map();
		for (const dong of this.dsDong) {
			thongKe.set(dong.loai, (thongKe.get(dong.loai) || 0) + dong.gia * dong.soLuong);
		}
		return Object.fromEntries(thongKe);
	}

	// 5. Dòng có thành tiền lớn nhất (bản sao, có thêm thanhTien); null nếu giỏ rỗng.
	dongDatNhat() {
		if (this.dsDong.length === 0) {
			return null;
		}
		const dong = this.dsDong.reduce((max, d) =>
			d.gia * d.soLuong > max.gia * max.soLuong ? d : max);
		return { ...dong, thanhTien: dong.gia * dong.soLuong };
	}

	// 6. Mảng BẢN SAO các dòng, mỗi dòng có thêm thuộc tính thanhTien.
	layDanhSach() {
		return this.dsDong.map(dong => ({ ...dong, thanhTien: dong.gia * dong.soLuong }));
	}

	// 7. Chuỗi JSON của mảng các dòng.
	xuatJSON() {
		return JSON.stringify(this.dsDong);
	}
}

// 8. Tạo lại một GioHang từ chuỗi JSON do xuatJSON() sinh ra.
function napGioHang(chuoiJSON) {
	const gioHang = new GioHang();
	for (const dong of JSON.parse(chuoiJSON)) {
		gioHang.them(dong, dong.soLuong);
	}
	return gioHang;
}

// ---------- CHẠY THỬ (không sửa) ----------
const gio = new GioHang();
gio.them(DANH_MUC[0], 100);
gio.them(DANH_MUC[3], 200);
gio.them(DANH_MUC[0], 50);
veGioHang(gio.layDanhSach(), gio.tongTien());
console.table(gio.layDanhSach());
hienThi(`JSON gửi lên máy chủ: ${gio.xuatJSON()}`);

// Lưu giỏ mẫu trên trình duyệt và khôi phục ở lần mở trang tiếp theo.
// Các GioHang tạo riêng trong bộ kiểm tra không ghi đè dữ liệu đã lưu.
const KHOA_GIO_HANG = "it4409-bai-2-gio-hang";

function luuGioHang() {
	try {
		localStorage.setItem(KHOA_GIO_HANG, gio.xuatJSON());
	} catch (loi) {
		console.warn("Không thể lưu giỏ hàng trên trình duyệt:", loi.message);
	}
}

try {
	const daLuu = localStorage.getItem(KHOA_GIO_HANG);
	if (daLuu !== null) {
		gio.dsDong = napGioHang(daLuu).dsDong;
		veGioHang(gio.layDanhSach(), gio.tongTien());
		document.getElementById("ket-qua").textContent = `JSON giỏ hàng đã khôi phục: ${gio.xuatJSON()}\n`;
	}
} catch (loi) {
	console.warn("Không thể khôi phục giỏ đã lưu; sử dụng giỏ mẫu:", loi.message);
}

luuGioHang();
window.addEventListener("pagehide", luuGioHang);
document.addEventListener("visibilitychange", () => {
	if (document.visibilityState === "hidden") {
		luuGioHang();
	}
});
